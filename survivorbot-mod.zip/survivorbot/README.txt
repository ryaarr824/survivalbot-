Survivor Bot (Fabric, Minecraft 26.3, Java 25)

BUILD
  Windows:  gradlew.bat build
  Mac/Linux: ./gradlew build
The jar is build/libs/survivorbot-1.0.0.jar (not the -sources one).
Put it in mods/ with Fabric API 0.166.2+26.3.

COMMANDS
  /sbot <name> spawn           spawn a bot (any name, e.g. /sbot Wemmbu spawn)
  /sbot <name> kill
  /sbot <name> flee            run from nearest real player
  /sbot <name> flee <player>   run only from that player
  /sbot list

Give the bot items by opening its inventory is not supported; use /give Wemmbu minecraft:cooked_beef 16 etc.
It uses: totems (offhand), ender pearls, golden apples, any food, and cobblestone/dirt/stone etc. to bridge and pillar.
