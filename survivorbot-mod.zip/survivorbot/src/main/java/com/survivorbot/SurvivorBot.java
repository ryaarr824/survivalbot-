package com.survivorbot;

import com.mojang.authlib.GameProfile;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.DisconnectionDetails;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.TickTask;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.food.FoodData;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** A fake player that tries to survive: flees, eats, pearls, re-equips totems, bridges and pillars. */
public class SurvivorBot extends ServerPlayer {
	private static final Set<Block> BUILD_BLOCKS = Set.of(Blocks.COBBLESTONE, Blocks.DIRT, Blocks.STONE,
			Blocks.NETHERRACK, Blocks.OAK_PLANKS, Blocks.DEEPSLATE, Blocks.COBBLED_DEEPSLATE);
	private static final Set<Item> BAD_FOOD = Set.of(Items.ROTTEN_FLESH, Items.SPIDER_EYE, Items.POISONOUS_POTATO,
			Items.PUFFERFISH, Items.CHORUS_FRUIT, Items.SUSPICIOUS_STEW, Items.GOLDEN_APPLE,
			Items.ENCHANTED_GOLDEN_APPLE);

	/** Name of the player to run from; null = nearest real player. */
	public String fleeFrom = null;

	private int pearlCooldown = 0;
	private int eatSlot = -1;
	private ItemStack eatPrev = ItemStack.EMPTY;
	private int pillarBaseY = Integer.MIN_VALUE;

	private enum Move { BLOCKED, WALK, JUMP, BRIDGE }

	public SurvivorBot(MinecraftServer server, ServerLevel level, GameProfile profile, ClientInformation info) {
		super(server, level, profile, info);
	}

	// ---------------------------------------------------------------- lifecycle (modelled on Carpet)

	@Override
	public void tick() {
		if (this.level().getServer().getTickCount() % 10 == 0) {
			this.connection.resetPosition();
			this.level().getChunkSource().move(this);
		}
		try {
			if (isAlive()) {
				brain(); // sets zza/xxa/jumping before the normal tick uses them
			}
			super.tick();
			this.doTick();
		} catch (NullPointerException ignored) {
		}
	}

	@Override
	public void die(DamageSource cause) {
		super.die(cause);
		setHealth(20);
		this.foodData = new FoodData();
		removeBot(this.getCombatTracker().getDeathMessage());
	}

	@Override
	public void kill(ServerLevel level) {
		removeBot(Component.literal("Killed"));
	}

	public void removeBot(Component reason) {
		MinecraftServer server = this.level().getServer();
		server.schedule(new TickTask(server.getTickCount(),
				() -> this.connection.onDisconnect(new DisconnectionDetails(reason))));
	}

	@Override
	public String getIpAddress() {
		return "127.0.0.1";
	}

	// ---------------------------------------------------------------- brain

	private void brain() {
		Inventory inv = getInventory();
		if (pearlCooldown > 0) pearlCooldown--;

		ServerPlayer threat = findThreat();
		double dist = threat == null ? 999 : Math.sqrt(distanceToSqr(threat));

		// currently eating: stand still until done, or abort if the threat gets close
		if (eatSlot >= 0) {
			boolean done = !isUsingItem();
			if (done || dist < 8) {
				if (!done) releaseUsingItem();
				endEat();
			} else {
				zza = 0;
				xxa = 0;
				setSprinting(false);
				return;
			}
		}

		// totem in offhand
		if (getOffhandItem().isEmpty()) {
			int s = findSlot(Items.TOTEM_OF_UNDYING);
			if (s >= 0) {
				ItemStack t = inv.getItem(s);
				inv.setItem(s, ItemStack.EMPTY);
				setItemInHand(InteractionHand.OFF_HAND, t);
			}
		}

		// pearl away when the threat is close and we're hurt (pearl does 5 damage, so not when very low)
		if (threat != null && dist < 7 && pearlCooldown == 0 && getHealth() <= 14 && getHealth() > 6) {
			int s = findSlot(Items.ENDER_PEARL);
			if (s >= 0) {
				throwPearl(s, threat);
				return;
			}
		}

		// golden apple when hurt and nobody is near
		if (getHealth() <= 10 && dist > 10) {
			int s = findSlot(Items.ENCHANTED_GOLDEN_APPLE);
			if (s < 0) s = findSlot(Items.GOLDEN_APPLE);
			if (s >= 0) {
				startEat(s);
				return;
			}
		}

		// normal food when hungry and nobody is near
		if (getFoodData().getFoodLevel() <= 14 && dist > 16) {
			int s = findFoodSlot();
			if (s >= 0) {
				startEat(s);
				return;
			}
		}

		flee(threat, dist);
	}

	private ServerPlayer findThreat() {
		ServerPlayer best = null;
		double bestD = Double.MAX_VALUE;
		for (ServerPlayer p : this.level().players()) {
			if (p == this || p instanceof SurvivorBot || p.isSpectator() || !p.isAlive()) continue;
			if (fleeFrom != null && !p.getName().getString().equalsIgnoreCase(fleeFrom)) continue;
			double d = distanceToSqr(p);
			if (d < bestD) {
				bestD = d;
				best = p;
			}
		}
		return best;
	}

	// ---------------------------------------------------------------- fleeing / building

	private void flee(ServerPlayer threat, double dist) {
		setJumping(isInWater());
		if (threat == null || dist > 40) {
			zza = 0;
			xxa = 0;
			setSprinting(false);
			pillarBaseY = Integer.MIN_VALUE;
			return;
		}

		Vec3 away = new Vec3(getX() - threat.getX(), 0, getZ() - threat.getZ());
		if (away.lengthSqr() < 1.0E-4) away = new Vec3(1, 0, 0);
		away = away.normalize();

		boolean hasBlocks = findBuildSlot() >= 0;
		double[] turns = {0, 0.6, -0.6, 1.2, -1.2, 1.9, -1.9};
		for (double t : turns) {
			Vec3 d = away.yRot((float) t);
			Move m = probe(d, hasBlocks);
			if (m == Move.BLOCKED) continue;

			float yaw = (float) (Mth.atan2(-d.x, d.z) * 57.29577951308232);
			setYRot(yaw);
			setYHeadRot(yaw);
			setXRot(10f);
			zza = 1.0f;
			xxa = 0;
			setSprinting(true);
			pillarBaseY = Integer.MIN_VALUE;
			if (m == Move.JUMP && onGround()) jumpFromGround();
			if (m == Move.BRIDGE) {
				Vec3 ahead = position().add(d.scale(0.9));
				placeBlock(BlockPos.containing(ahead.x, getY() - 1, ahead.z));
			}
			return;
		}

		// cornered: stop and pillar up if there's a threat close by
		zza = 0;
		xxa = 0;
		setSprinting(false);
		if (dist < 12 && hasBlocks) {
			if (onGround()) {
				pillarBaseY = Mth.floor(getY());
				jumpFromGround();
			} else if (pillarBaseY != Integer.MIN_VALUE && getY() >= pillarBaseY + 1.0
					&& getDeltaMovement().y <= 0.1) {
				placeBlock(new BlockPos(Mth.floor(getX()), pillarBaseY, Mth.floor(getZ())));
			}
		}
	}

	private Move probe(Vec3 d, boolean hasBlocks) {
		ServerLevel lvl = this.level();
		Vec3 step = d.scale(0.9);
		AABB box = getBoundingBox().move(step);
		Vec3 ahead = position().add(step);
		if (lvl.noCollision(this, box)) {
			if (lavaAt(ahead)) return Move.BLOCKED;
			if (!lvl.noCollision(this, box.expandTowards(0, -3, 0))) return Move.WALK; // ground within 3 blocks
			return hasBlocks ? Move.BRIDGE : Move.BLOCKED;
		}
		if (onGround() && lvl.noCollision(this, box.move(0, 1.05, 0))) return Move.JUMP;
		return Move.BLOCKED;
	}

	private boolean lavaAt(Vec3 p) {
		for (int dy = 0; dy >= -2; dy--) {
			if (this.level().getFluidState(BlockPos.containing(p.x, p.y + dy, p.z)).is(FluidTags.LAVA)) return true;
		}
		return false;
	}

	private boolean placeBlock(BlockPos pos) {
		ServerLevel lvl = this.level();
		if (!lvl.getBlockState(pos).canBeReplaced()) return false;
		int s = findBuildSlot();
		if (s < 0) return false;
		ItemStack st = getInventory().getItem(s);
		lvl.setBlockAndUpdate(pos, ((BlockItem) st.getItem()).getBlock().defaultBlockState());
		st.shrink(1);
		return true;
	}

	// ---------------------------------------------------------------- items

	private void throwPearl(int slot, ServerPlayer threat) {
		Inventory inv = getInventory();
		ItemStack pearl = inv.getItem(slot);
		ItemStack old = getItemInHand(InteractionHand.MAIN_HAND);
		setItemInHand(InteractionHand.MAIN_HAND, pearl);
		inv.setItem(slot, old);

		double dx = getX() - threat.getX();
		double dz = getZ() - threat.getZ();
		float yaw = (float) (Mth.atan2(-dx, dz) * 57.29577951308232);
		setYRot(yaw);
		setYHeadRot(yaw);
		setXRot(-35f);

		this.gameMode.useItem(this, this.level(), pearl, InteractionHand.MAIN_HAND);

		ItemStack now = getItemInHand(InteractionHand.MAIN_HAND);
		setItemInHand(InteractionHand.MAIN_HAND, old);
		inv.setItem(slot, now);
		pearlCooldown = 100;
	}

	private void startEat(int slot) {
		Inventory inv = getInventory();
		ItemStack food = inv.getItem(slot);
		eatPrev = getItemInHand(InteractionHand.MAIN_HAND);
		eatSlot = slot;
		setItemInHand(InteractionHand.MAIN_HAND, food);
		inv.setItem(slot, eatPrev);
		zza = 0;
		xxa = 0;
		setSprinting(false);
		this.gameMode.useItem(this, this.level(), food, InteractionHand.MAIN_HAND);
	}

	private void endEat() {
		if (eatSlot >= 0 && eatSlot < 36) {
			ItemStack cur = getItemInHand(InteractionHand.MAIN_HAND);
			setItemInHand(InteractionHand.MAIN_HAND, eatPrev);
			getInventory().setItem(eatSlot, cur);
		}
		eatSlot = -1;
		eatPrev = ItemStack.EMPTY;
	}

	private int findSlot(Item item) {
		Inventory inv = getInventory();
		for (int i = 0; i < 36; i++) {
			if (inv.getItem(i).is(item)) return i;
		}
		return -1;
	}

	private int findFoodSlot() {
		Inventory inv = getInventory();
		for (int i = 0; i < 36; i++) {
			ItemStack s = inv.getItem(i);
			if (!s.isEmpty() && s.has(DataComponents.FOOD) && !BAD_FOOD.contains(s.getItem())) return i;
		}
		return -1;
	}

	private int findBuildSlot() {
		Inventory inv = getInventory();
		for (int i = 0; i < 36; i++) {
			ItemStack s = inv.getItem(i);
			if (!s.isEmpty() && s.getItem() instanceof BlockItem bi && BUILD_BLOCKS.contains(bi.getBlock())) return i;
		}
		return -1;
	}
}
