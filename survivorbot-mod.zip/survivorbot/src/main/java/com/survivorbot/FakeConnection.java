package com.survivorbot;

import io.netty.channel.ChannelFutureListener;
import io.netty.channel.embedded.EmbeddedChannel;
import java.lang.reflect.Field;
import net.minecraft.network.Connection;
import net.minecraft.network.PacketListener;
import net.minecraft.network.ProtocolInfo;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.PacketFlow;

/** Network connection that goes nowhere. Same idea as Carpet's FakeClientConnection. */
public class FakeConnection extends Connection {
	public FakeConnection() {
		super(PacketFlow.SERVERBOUND);
		// An open channel makes ender pearls able to teleport the bot.
		try {
			Field f = Connection.class.getDeclaredField("channel");
			f.setAccessible(true);
			f.set(this, new EmbeddedChannel());
		} catch (ReflectiveOperationException e) {
			throw new RuntimeException("Could not set fake channel (field 'channel' missing?)", e);
		}
	}

	@Override
	public void setReadOnly() {
	}

	@Override
	public void send(Packet<?> packet, ChannelFutureListener listener, boolean flush) {
	}

	@Override
	public void handleDisconnection() {
	}

	@Override
	public void setListenerForServerboundHandshake(PacketListener listener) {
	}

	@Override
	public <T extends PacketListener> void setupInboundProtocol(ProtocolInfo<T> info, T listener) {
	}
}
