package com.survivorbot;

import com.mojang.authlib.GameProfile;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundEntityPositionSyncPacket;
import net.minecraft.network.protocol.game.ClientboundRotateHeadPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ClientInformation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ClientDebugInfo;
import net.minecraft.server.network.CommonListenerCookie;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.Vec3;

/**
 * Commands (anyone can use them - add .requires(...) if you run this on a public server):
 *   /sbot <name> spawn           spawn a bot at your position
 *   /sbot <name> kill            remove it
 *   /sbot <name> flee            run from the nearest real player (default)
 *   /sbot <name> flee <player>   run only from that player
 *   /sbot list
 */
public class SurvivorBotMod implements ModInitializer {
	@Override
	public void onInitialize() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
				dispatcher.register(Commands.literal("sbot")
						.then(Commands.literal("list").executes(c -> list(c.getSource())))
						.then(Commands.argument("name", StringArgumentType.word())
								.then(Commands.literal("spawn").executes(c -> spawn(c.getSource(), name(c))))
								.then(Commands.literal("kill").executes(c -> kill(c.getSource(), name(c))))
								.then(Commands.literal("flee")
										.executes(c -> flee(c.getSource(), name(c), null))
										.then(Commands.argument("player", StringArgumentType.word())
												.executes(c -> flee(c.getSource(), name(c),
														StringArgumentType.getString(c, "player"))))))));
	}

	private static String name(CommandContext<CommandSourceStack> c) {
		return StringArgumentType.getString(c, "name");
	}

	private static SurvivorBot find(CommandSourceStack src, String name) {
		ServerPlayer p = src.getServer().getPlayerList().getPlayerByName(name);
		return p instanceof SurvivorBot b ? b : null;
	}

	private static int spawn(CommandSourceStack src, String name) {
		MinecraftServer server = src.getServer();
		if (!name.matches("[A-Za-z0-9_]{1,16}")) {
			src.sendFailure(Component.literal("Name must be 1-16 letters, digits or underscores."));
			return 0;
		}
		if (server.getPlayerList().getPlayerByName(name) != null) {
			src.sendFailure(Component.literal(name + " is already online."));
			return 0;
		}

		UUID uuid = UUIDUtil.createOfflinePlayerUUID(name);
		GameProfile profile = new GameProfile(uuid, name);
		ServerLevel level = src.getLevel();
		Vec3 pos = src.getPosition();
		float yaw = src.getEntity() != null ? src.getEntity().getYRot() : 0f;

		SurvivorBot bot = new SurvivorBot(server, level, profile, ClientInformation.createDefault());
		server.getPlayerList().placeNewPlayer(new FakeConnection(), bot,
				new CommonListenerCookie(profile, 0, bot.clientInformation(), false, new ClientDebugInfo()));
		bot.stopRiding();
		bot.teleportTo(level, pos.x, pos.y, pos.z, Set.of(), yaw, 0f, true);
		bot.setHealth(20.0F);
		bot.unsetRemoved();
		bot.gameMode.changeGameModeForPlayer(GameType.SURVIVAL);
		server.getPlayerList().broadcastAll(
				new ClientboundRotateHeadPacket(bot, (byte) (bot.yHeadRot * 256 / 360)), level.dimension());
		server.getPlayerList().broadcastAll(ClientboundEntityPositionSyncPacket.of(bot), level.dimension());

		src.sendSuccess(() -> Component.literal("Spawned " + name), true);
		return 1;
	}

	private static int kill(CommandSourceStack src, String name) {
		SurvivorBot bot = find(src, name);
		if (bot == null) {
			src.sendFailure(Component.literal("No bot named " + name));
			return 0;
		}
		bot.removeBot(Component.literal("Removed"));
		src.sendSuccess(() -> Component.literal("Removed " + name), true);
		return 1;
	}

	private static int flee(CommandSourceStack src, String name, String target) {
		SurvivorBot bot = find(src, name);
		if (bot == null) {
			src.sendFailure(Component.literal("No bot named " + name));
			return 0;
		}
		bot.fleeFrom = target;
		src.sendSuccess(() -> Component.literal(name + (target == null
				? " now flees from the nearest player" : " now flees from " + target)), true);
		return 1;
	}

	private static int list(CommandSourceStack src) {
		StringBuilder sb = new StringBuilder();
		for (ServerPlayer p : src.getServer().getPlayerList().getPlayers()) {
			if (p instanceof SurvivorBot) {
				if (!sb.isEmpty()) sb.append(", ");
				sb.append(p.getName().getString());
			}
		}
		String out = sb.isEmpty() ? "No bots." : "Bots: " + sb;
		src.sendSuccess(() -> Component.literal(out), false);
		return 1;
	}
}
